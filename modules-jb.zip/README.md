sultan-kernel-bruce-linaro3
===========================

I made this repo because Git was taking forever to clone the sultan-kernel-bruce-linaro2 repo

This source is, obviously, publicly available for use by everyone. If you use a component from my source or use my source in its entirety then remember to retain proper authorship/give proper credit.
